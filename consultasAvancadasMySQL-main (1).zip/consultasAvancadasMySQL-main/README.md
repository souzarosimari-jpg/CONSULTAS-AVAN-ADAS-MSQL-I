# consultasAvancadasMySQL
Repositório voltado para armazenagem dos arquivos necessários para aula
